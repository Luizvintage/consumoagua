fun main() {
    var totalLitros = 0.0

    while (true) {
        println("Escolha uma opção:")
        println("1 - Registrar a quantidade de garrafas consumidas")
        println("2 - Verificar o total de litros consumidos hoje")
        println("3 - Sair")

        val opcao = readLine()?.toIntOrNull() ?: 0

        when (opcao) {
            1 -> {
                println("Quantas garrafas de 500 ml você consumiu?")
                val garrafasConsumidas = readLine()?.toIntOrNull() ?: 0
                totalLitros += garrafasConsumidas * 0.5
                println("$garrafasConsumidas garrafa(s) adicionada(s) ao total.")
            }
            2 -> {
                println("Total de litros consumidos hoje: $totalLitros litro(s)")
            }
            3 -> {
                println("Saindo do programa.")
                return
            }
            else -> {
                println("Opção inválida. Por favor, escolha uma opção válida.")
            }
        }
    }
}
